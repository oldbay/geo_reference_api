*******
Authors
*******

Leads
=====

- Steven Loria `@sloria <https://github.com/sloria>`_

Contributors
============

- Rob MacKinnon `@rmackinnon <https://github.com/rmackinnon>`_
- Josh Carp `@jmcarp <https://github.com/jmcarp>`_
- Jason Mitchell `@mitchej123 <https://github.com/mitchej123>`_
- Douglas Russell `@dpwrussell <https://github.com/dpwrussell>`_
- Rudá Porto Filgueiras `@rudaporto <https://github.com/rudaporto>`_
- Sean Harrington `@seanharr11 <https://github.com/seanharr11>`_
- Eric Wittle `@ewittle <https://github.com/ewittle>`_
- Alex Rothberg `@cancan101 <https://github.com/cancan101>`_
- Vlad Frolov `@frol <https://github.com/frol>`_
- Kelvin Hammond `@kelvinhammond <https://github.com/kelvinhammond>`_
- Yuri Heupa `@YuriHeupa <https://github.com/YuriHeupa>`_
- Jeremy Muhlich `@jmuhlich <https://github.com/jmuhlich>`_
- Ilya Chistyakov `@ilya-chistyakov <https://github.com/ilya-chistyakov>`_
- Victor Gavro `@vgavro <https://github.com/vgavro>`_
- Maciej Barański `@gtxm <https://github.com/gtxm>`_
- Jared Deckard `@deckar01 <https://github.com/deckar01>`_
- AbdealiJK `@AbdealiJK <https://github.com/AbdealiJK>`_
- jean-philippe serafin `@jeanphix <https://github.com/jeanphix>`_
- Jack Smith `@jacksmith15 <https://github.com/jacksmith15>`_
- Kazantcev Andrey `@heckad <https://github.com/heckad>`_
- Samuel Searles-Bryant `@samueljsb <https://github.com/samueljsb>`_
