********************
SQLAthanor License
********************

.. include:: ../LICENSE
