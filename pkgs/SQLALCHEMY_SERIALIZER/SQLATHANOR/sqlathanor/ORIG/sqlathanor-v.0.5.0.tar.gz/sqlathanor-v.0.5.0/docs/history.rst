*****************
Release History
*****************

.. contents::
  :depth: 3
  :backlinks: entry

.. include:: ../CHANGES.rst
