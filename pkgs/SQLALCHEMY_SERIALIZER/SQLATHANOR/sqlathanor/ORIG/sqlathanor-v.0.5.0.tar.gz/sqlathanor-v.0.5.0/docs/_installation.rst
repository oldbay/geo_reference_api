To install **SQLAthanor**, just execute:

.. code:: bash

 $ pip install sqlathanor
