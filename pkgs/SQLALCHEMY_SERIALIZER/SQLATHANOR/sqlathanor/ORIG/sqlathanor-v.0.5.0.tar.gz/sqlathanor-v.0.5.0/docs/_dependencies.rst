.. tabs::

  .. tab:: Python 3.x

    * `SQLAlchemy v.0.9 <https://www.sqlalchemy.org>`_ or higher
    * `PyYAML v3.10 <https://github.com/yaml/pyyaml>`_ or higher
    * `simplejson v3.0 <https://simplejson.readthedocs.io/en/latest/>`_ or higher
    * `Validator-Collection v1.3.0 <https://github.com/insightindustry/validator-collection>`_ or higher

  .. tab:: Python 2.x

    * `SQLAlchemy v.0.9 <https://www.sqlalchemy.org>`_ or higher
    * `PyYAML v3.10 <https://github.com/yaml/pyyaml>`_ or higher
    * `simplejson v3.0 <https://simplejson.readthedocs.io/en/latest/>`_ or higher
    * `Validator-Collection v1.3.0 <https://github.com/insightindustry/validator-collection>`_ or higher
