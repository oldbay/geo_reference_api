*****************
Release History
*****************

.. sidebar:: Contributors

  .. include:: _contributors.rst

.. contents::
  :depth: 3
  :backlinks: entry

.. include:: ../CHANGES.rst
