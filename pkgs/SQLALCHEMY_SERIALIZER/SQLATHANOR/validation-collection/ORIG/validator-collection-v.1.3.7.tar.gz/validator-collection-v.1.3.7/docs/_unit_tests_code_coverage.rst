.. list-table::
  :widths: 10 90
  :header-rows: 1

  * - Branch
    - Unit Tests
  * - `latest <https://github.com/insightindustry/validator-collection/tree/master>`_
    -
      .. image:: https://travis-ci.org/insightindustry/validator-collection.svg?branch=master
        :target: https://travis-ci.org/insightindustry/validator-collection
        :alt: Build Status (Travis CI)

      .. image:: https://codecov.io/gh/insightindustry/validator-collection/branch/master/graph/badge.svg
        :target: https://codecov.io/gh/insightindustry/validator-collection
        :alt: Code Coverage Status (Codecov)

      .. image:: https://readthedocs.org/projects/validator-collection/badge/?version=latest
        :target: http://validator-collection.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status (ReadTheDocs)

  * - `v. 1.3 <https://github.com/insightindustry/validator-collection/tree/v.1.3.7>`_
    -
      .. image:: https://travis-ci.org/insightindustry/validator-collection.svg?branch=v.1.3.7
         :target: https://travis-ci.org/insightindustry/validator-collection
         :alt: Build Status (Travis CI)

      .. image:: https://codecov.io/gh/insightindustry/validator-collection/branch/v.1.3.7/graph/badge.svg
         :target: https://codecov.io/gh/insightindustry/validator-collection
         :alt: Code Coverage Status (Codecov)

      .. image:: https://readthedocs.org/projects/validator-collection/badge/?version=v.1.3.7
         :target: http://validator-collection.readthedocs.io/en/latest/?badge=v.1.3.7
         :alt: Documentation Status (ReadTheDocs)

  * - `v. 1.2 <https://github.com/insightindustry/validator-collection/tree/v.1.2.0>`_
    -
      .. image:: https://travis-ci.org/insightindustry/validator-collection.svg?branch=v.1.2.0
         :target: https://travis-ci.org/insightindustry/validator-collection
         :alt: Build Status (Travis CI)

      .. image:: https://codecov.io/gh/insightindustry/validator-collection/branch/v.1.2.0/graph/badge.svg
         :target: https://codecov.io/gh/insightindustry/validator-collection
         :alt: Code Coverage Status (Codecov)

      .. image:: https://readthedocs.org/projects/validator-collection/badge/?version=v.1.2.0
         :target: http://validator-collection.readthedocs.io/en/latest/?badge=v.1.2.0
         :alt: Documentation Status (ReadTheDocs)

  * - `v. 1.1 <https://github.com/insightindustry/validator-collection/tree/v.1.1.0>`_
    -
      .. image:: https://travis-ci.org/insightindustry/validator-collection.svg?branch=v.1.1.0
         :target: https://travis-ci.org/insightindustry/validator-collection
         :alt: Build Status (Travis CI)

      .. image:: https://codecov.io/gh/insightindustry/validator-collection/branch/v.1.1.0/graph/badge.svg
         :target: https://codecov.io/gh/insightindustry/validator-collection
         :alt: Code Coverage Status (Codecov)

      .. image:: https://readthedocs.org/projects/validator-collection/badge/?version=v.1.1.0
         :target: http://validator-collection.readthedocs.io/en/latest/?badge=v.1.1.0
         :alt: Documentation Status (ReadTheDocs)

  * - `v. 1.0.0 <https://github.com/insightindustry/validator-collection/tree/v1-0-0>`_
    -
      .. image:: https://travis-ci.org/insightindustry/validator-collection.svg?branch=v.1.0.0
        :target: https://travis-ci.org/insightindustry/validator-collection
        :alt: Build Status (Travis CI)

      .. image:: https://codecov.io/gh/insightindustry/validator-collection/branch/v1-0-0/graph/badge.svg
        :target: https://codecov.io/gh/insightindustry/validator-collection
        :alt: Code Coverage Status (Codecov)

      .. image:: https://readthedocs.org/projects/validator-collection/badge/?version=v.1.0.0
        :target: http://validator-collection.readthedocs.io/en/latest/?badge=v.1.0.0
        :alt: Documentation Status (ReadTheDocs)

  * - `develop <https://github.com/insightindustry/validator-collection/tree/develop>`_
    -
      .. image:: https://travis-ci.org/insightindustry/validator-collection.svg?branch=develop
        :target: https://travis-ci.org/insightindustry/validator-collection
        :alt: Build Status (Travis CI)

      .. image:: https://codecov.io/gh/insightindustry/validator-collection/branch/develop/graph/badge.svg
        :target: https://codecov.io/gh/insightindustry/validator-collection
        :alt: Code Coverage Status (Codecov)

      .. image:: https://readthedocs.org/projects/validator-collection/badge/?version=develop
        :target: http://validator-collection.readthedocs.io/en/latest/?badge=develop
        :alt: Documentation Status (ReadTheDocs)
