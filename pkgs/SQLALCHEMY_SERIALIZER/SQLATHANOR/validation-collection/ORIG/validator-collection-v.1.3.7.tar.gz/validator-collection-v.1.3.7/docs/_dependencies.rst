.. tabs::

  .. tab:: Python 3.x

    * `jsonschema <https://pypi.org/project/jsonschema/>`_ for JSON Schema validation

  .. tab:: Python 2.x

    * `jsonschema <https://pypi.org/project/jsonschema/>`_ for JSON Schema validation
    * The `regex <https://pypi.python.org/pypi/regex>`_ drop-in replacement for
      Python's (buggy) standard :class:`re <python:re>` module.

      .. note::

        This conditional dependency will be automatically installed if you are
        installing to Python 2.x.
