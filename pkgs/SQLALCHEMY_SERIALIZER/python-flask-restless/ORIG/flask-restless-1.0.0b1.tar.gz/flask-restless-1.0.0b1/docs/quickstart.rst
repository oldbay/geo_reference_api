Quickstart
==========

For the restless:

.. literalinclude:: ../examples/quickstart.py
   :linenos:

You may find this example at :file:`examples/quickstart.py` in the source
distribution; you may also `view it online`_. Further examples can be found in
the :file:`examples/` directory in the source distribution or `on the web`_

.. _view it online: https://github.com/jfinkels/flask-restless/tree/master/examples/quickstart.py
.. _on the web: https://github.com/jfinkels/flask-restless/tree/master/examples>
