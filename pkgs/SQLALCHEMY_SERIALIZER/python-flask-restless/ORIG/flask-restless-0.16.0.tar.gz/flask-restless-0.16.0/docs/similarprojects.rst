Similar projects
================

If Flask-Restless doesn't work for you, here are some similar Python packages
that intend to simplify the creation of ReSTful APIs (in various combinations
of Web frameworks and database backends):

- `Eve <http://python-eve.org>`_
- `Flask-Peewee <https://flask-peewee.readthedocs.org>`_
- `Flask-RESTful <https://flask-restful.readthedocs.org>`_
- `simpleapi <https://simpleapi.readthedocs.org>`_
- `Tastypie <https://flask-restful.readthedocs.org>`_
