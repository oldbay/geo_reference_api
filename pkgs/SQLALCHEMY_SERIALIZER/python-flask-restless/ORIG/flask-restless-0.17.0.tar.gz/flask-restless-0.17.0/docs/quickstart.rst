Quickstart
==========

For the restless:

.. literalinclude:: ../examples/quickstart.py
   :linenos:

You may find this example at :file:`examples/quickstart.py` in the source
distribution; you may also view it online at `GitHub
<https://github.com/jfinkels/flask-restless/tree/master/examples/quickstart.py>`_.

Further examples can be found in the :file:`examples/` directory in the source
distribution or `on the web
<https://github.com/jfinkels/flask-restless/tree/master/examples>`_.
